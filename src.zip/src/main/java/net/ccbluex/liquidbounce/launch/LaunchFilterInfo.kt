package net.ccbluex.liquidbounce.launch

@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class LaunchFilterInfo(val filters: Array<EnumLaunchFilter>)
