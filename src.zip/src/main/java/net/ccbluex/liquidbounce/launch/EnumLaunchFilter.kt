package net.ccbluex.liquidbounce.launch

enum class EnumLaunchFilter {
    FANCY_UI,
    LEGACY_UI
}