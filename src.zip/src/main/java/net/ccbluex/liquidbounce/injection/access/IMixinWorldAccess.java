package net.ccbluex.liquidbounce.injection.access;

public interface IMixinWorldAccess {

    void markBlockForUpdate(int var1, int var2, int var3);

    void notifyLightSet(int var1, int var2, int var3);
}
